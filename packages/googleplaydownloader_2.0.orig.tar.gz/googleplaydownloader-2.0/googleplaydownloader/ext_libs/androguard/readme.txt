These files come from the Androguard project ( https://github.com/androguard/androguard)
This project is released under the Apache License, Version 2.0.

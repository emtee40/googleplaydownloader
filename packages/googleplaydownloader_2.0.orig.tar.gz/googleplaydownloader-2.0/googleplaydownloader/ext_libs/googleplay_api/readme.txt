These files come from APKcrawler ( https://github.com/opengapps/apkcrawler ) which updated the GooglePlayAPI project ( https://github.com/egirault/googleplay-api/ )
This project is released under the BSD license.
